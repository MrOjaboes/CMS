<?php session_start()?>   
 <?php
 $connect = mysqli_connect('localhost', 'root', '', 'cms');
   $id = $_SESSION['User_id'];
 $activity = $_SESSION['Title'].' '.$_SESSION['Name'].' '.'Has just logged out....';
 $sql = "INSERT INTO activities(User_id, Activity) VALUES('$id', '$activity')";
$query = mysqli_query($connect, $sql) or die(mysqli_error($connect));

 session_destroy();
 $message='<h3>Good Bye </h3>';
 if(@$message){
header("Refresh:1; url=login.php");
 }
 
 ?>
 
 
 
 <?php include('includes/header1.php');?>
<body style="background-image: url(./images/mfbg.JPG);
  background-position:absolute;" class="hold-transition login-page" >
<div class="login-box">
  <div class="login-logo">
    <a href="#"><b>C M S</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg"></p>
 <hr />
 <div class="alert alert-success">
  <p class="text-center"><?php echo @$message;?> </br>  
  <span class="text-center" style="font-size:25px !important;"><?php echo '<h3>'.$_SESSION['Username'].'</h3>';?></span>
</p>
</div>
  <hr />
  </div>
  <!-- /.login-box-body -->
</div>
 

<?php include('includes/footer.php');?> 
 
 
  
 